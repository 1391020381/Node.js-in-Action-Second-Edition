# 非阻塞 I/O
* 事件、异步API、非阻塞I/0
# 事件轮询 

# ES2015、Node和V8
* http://node.green 上汇总了Node支持的ES2015特性。
* libuv,它是负责处理I/0的。V8负责JavaScript代码的解释和执行。用C++绑定层可将libuv和V8结合起来。
* 使用特性组  shipping staged in progress
* 了解Node的发布计划
* 安装Node
# Node自带的工具
* npm
* 核心模块
1. 